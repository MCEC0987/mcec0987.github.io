<?php
session_start();
$dataFile = 'data.txt';
$lines = file_exists($dataFile) ? file($dataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

$config = [
    'site_name' => '网站收录站',
    'site_desc' => '优质网站收录分享平台',
    'per_page' => 12,
    'footer_text' => '© 2025 网站收录站 版权所有',
    'icp' => '',
    'close_submit' => 0,
    'is_audit' => 0,
    'intro_min' => 10,
    'intro_max' => 500,
    'allow_html_tags' => '<a><img><video><p><br><strong><em>',
    'admin_user' => 'admin',
    'admin_pwd' => 'e10adc3949ba59abbe56e057f20f883e',
    'recycle_days' => 7,
    'dead_link_days' => 30,
    'icon_size' => 128
];

$sites = [];
$logs = [];
$banned_ips = [];

if (!empty($lines)) {
    $cfg = json_decode($lines[0], true);
    if (is_array($cfg)) {
        $config = array_merge($config, $cfg);
        array_shift($lines);
    }
    foreach ($lines as $line) {
        $row = json_decode($line, true);
        if (!$row) continue;
        if (isset($row['action'])) $logs[] = $row;
        elseif (isset($row['ban_time'])) $banned_ips[] = $row;
        elseif (isset($row['id'])) $sites[] = $row;
    }
}

// 直接跳转 无中转提示
if (isset($_GET['viewid'])) {
    $vid = (int)$_GET['viewid'];
    foreach ($sites as &$s) {
        if ((int)$s['id'] === $vid && empty($s['deleted_at'])) {
            $s['view']++;
            $s['last_view'] = time();
            break;
        }
    }
    unset($s);
    $newAll = [json_encode($config, JSON_UNESCAPED_UNICODE)];
    foreach ($sites as $s) $newAll[] = json_encode($s, JSON_UNESCAPED_UNICODE);
    foreach ($logs as $l) $newAll[] = json_encode($l, JSON_UNESCAPED_UNICODE);
    foreach ($banned_ips as $b) $newAll[] = json_encode($b, JSON_UNESCAPED_UNICODE);
    file_put_contents($dataFile, implode(PHP_EOL, $newAll) . PHP_EOL);
    header('Location: ' . htmlspecialchars($_GET['url']));
    exit;
}

$keyword = trim($_GET['kw'] ?? '');
$showSites = [];
foreach ($sites as $s) {
    if (empty($s['deleted_at']) && (!$config['is_audit'] || $s['status'] == 1)) {
        $showSites[] = $s;
    }
}

if ($keyword !== '') {
    $temp = [];
    foreach ($showSites as $s) {
        if (stripos($s['name'], $keyword) !== false || stripos(strip_tags($s['intro']), $keyword) !== false) {
            $temp[] = $s;
        }
    }
    $showSites = $temp;
}

$sortType = isset($_GET['sort']) ? $_GET['sort'] : 'default';
$topList = [];
$normalList = [];
foreach ($showSites as $item) {
    if (!empty($item['top']) && $item['top'] == 1) {
        $topList[] = $item;
    } else {
        $normalList[] = $item;
    }
}

switch ($sortType) {
    case 'new': usort($normalList, fn($a,$b)=>strtotime($b['time'])-strtotime($a['time'])); break;
    case 'random': shuffle($normalList); break;
    case 'hot': usort($normalList, fn($a,$b)=>$b['view']-$a['view']); break;
}
$finalList = array_merge($topList, $normalList);

$total = count($finalList);
$perPage = $config['per_page'];
$totalPage = ceil($total / $perPage);
$page = max(1, isset($_GET['page']) ? (int)$_GET['page'] : 1);
$start = ($page - 1) * $perPage;
$pageList = array_slice($finalList, $start, $perPage);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($config['site_name']); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($config['site_desc']); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mdui@1.0.2/dist/css/mdui.min.css">
    <script src="https://cdn.jsdelivr.net/npm/mdui@1.0.2/dist/js/mdui.min.js"></script>
    <style>
        .icon-default{background:#eee;padding:10px;border-radius:8px;text-align:center;}
        .intro-collapse{max-height:60px;overflow:hidden;position:relative;}
        .intro-collapse::after{content:"";position:absolute;bottom:0;left:0;right:0;height:30px;background:linear-gradient(transparent,#fff);}
        .dark .intro-collapse::after{background:linear-gradient(transparent,#303030);}
        .tag{padding:2px 6px;border-radius:4px;font-size:12px;margin-left:8px;}
        .tag-recommend{background:#4caf50;color:white;}
        .tag-danger{background:#f44336;color:white;}
        footer{margin-top:40px;padding:20px 0;text-align:center;color:#666;border-top:1px solid #eee;}
        .dark footer{border-top-color:#424242;color:#999;}
    </style>
</head>
<body class="mdui-theme-primary-indigo mdui-theme-accent-pink">
    <header class="mdui-appbar mdui-appbar-fixed">
        <div class="mdui-toolbar mdui-color-theme">
            <a href="index.php" class="mdui-typo-headline"><?php echo htmlspecialchars($config['site_name']); ?></a>
            <div class="mdui-toolbar-spacer"></div>
            <button class="mdui-btn mdui-btn-icon mdui-text-color-white" id="themeToggle" title="切换主题">
                <i class="mdui-icon-dark-mode"></i>
            </button>
            <!-- 【修复】移动端显示短文字"收录"，桌面端显示"收录网站"，所有屏幕都能看到 -->
            <?php if(!$config['close_submit']): ?>
            <a href="upload.php" class="mdui-btn mdui-text-color-white mdui-hidden-sm-down">收录网站</a>
            <a href="upload.php" class="mdui-btn mdui-text-color-white mdui-hidden-md-up">收录</a>
            <?php endif; ?>
            <a href="admin.php" class="mdui-btn mdui-text-color-white">管理</a>
        </div>
    </header>

    <div class="mdui-container" style="margin-top:80px;">
        <div class="mdui-row mdui-m-b-4">
            <div class="mdui-col-xs-12 mdui-col-md-6 mdui-col-offset-md-3">
                <form method="get" action="index.php">
                    <div class="mdui-textfield mdui-textfield-floating-label">
                        <label>搜索网站名称/介绍</label>
                        <input type="text" name="kw" class="mdui-textfield-input" value="<?php echo htmlspecialchars($keyword); ?>">
                    </div>
                    <button type="submit" class="mdui-btn mdui-btn-raised mdui-color-theme mdui-float-right">搜索</button>
                    <a href="index.php" class="mdui-btn mdui-float-right mdui-m-r-2">重置</a>
                </form>
            </div>
        </div>

        <div class="mdui-btn-group mdui-m-b-4" style="display:flex;justify-content:center;flex-wrap:wrap;">
            <a href="?sort=default&kw=<?php echo urlencode($keyword); ?>" class="mdui-btn <?php echo $sortType=='default'?'mdui-color-theme mdui-text-color-white':''; ?>">默认排序</a>
            <a href="?sort=new&kw=<?php echo urlencode($keyword); ?>" class="mdui-btn <?php echo $sortType=='new'?'mdui-color-theme mdui-text-color-white':''; ?>">最新发布</a>
            <a href="?sort=random&kw=<?php echo urlencode($keyword); ?>" class="mdui-btn <?php echo $sortType=='random'?'mdui-color-theme mdui-text-color-white':''; ?>">随机推荐</a>
            <a href="?sort=hot&kw=<?php echo urlencode($keyword); ?>" class="mdui-btn <?php echo $sortType=='hot'?'mdui-color-theme mdui-text-color-white':''; ?>">热门排行</a>
        </div>

        <div class="mdui-row mdui-grid-list">
            <?php if(empty($pageList)): ?>
                <div class="mdui-col-xs-12 mdui-text-center mdui-padding-32">
                    <div class="mdui-typo-title">暂无收录网站</div>
                    <?php if(!$config['close_submit']): ?>
                    <a href="upload.php" class="mdui-btn mdui-color-theme mdui-m-t-3">立即提交</a>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach($pageList as $v): ?>
                    <div class="mdui-col-xs-12 mdui-col-sm-6 mdui-col-md-4 mdui-col-lg-3">
                        <div class="mdui-card mdui-m-b-3 <?php echo !empty($v['top'])&&$v['top']==1?'mdui-shadow-8':''; ?>">
                            <?php if(!empty($v['top'])&&$v['top']==1): ?>
                                <div class="mdui-card-header mdui-color-red mdui-text-color-white mdui-text-center">【置顶推荐】</div>
                            <?php endif; ?>
                            <div class="mdui-card-media mdui-text-center mdui-padding-16">
                                <img src="<?php echo htmlspecialchars($v['icon']); ?>" style="width:80px;height:80px;border-radius:8px;" 
                                onerror="this.style.display='none';this.nextElementSibling.style.display='block';">
                                <div class="icon-default" style="width:80px;height:80px;display:none;">无图标</div>
                            </div>
                            <div class="mdui-card-primary">
                                <div class="mdui-card-primary-title">
                                    <?php echo htmlspecialchars($v['name']); ?>
                                    <?php if($v['tag']=='recommend'): ?>
                                        <span class="tag tag-recommend">推荐</span>
                                    <?php elseif($v['tag']=='danger'): ?>
                                        <span class="tag tag-danger">危险</span>
                                    <?php endif; ?>
                                </div>
                                <div class="mdui-card-subtitle">访问量：<?php echo $v['view']; ?></div>
                            </div>
                            <div class="mdui-card-actions">
                                <button class="mdui-btn mdui-btn-raised mdui-color-theme" onclick="showInfo(<?php echo htmlspecialchars(json_encode($v)); ?>)">查看详情</button>
                                <a href="?viewid=<?php echo $v['id']; ?>&url=<?php echo urlencode($v['url']); ?>" class="mdui-btn">直达网站</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <?php if($totalPage > 1): ?>
        <div class="mdui-center mdui-m-t-4" style="text-align:center;">
            <div class="mdui-pagination">
                <?php if($page > 1): ?>
                <a href="?page=<?php echo $page-1; ?>&sort=<?php echo $sortType; ?>&kw=<?php echo urlencode($keyword); ?>" class="mdui-btn mdui-btn-icon"><i class="mdui-icon-chevron-left"></i></a>
                <?php endif; ?>
                <?php for($i=1;$i<=$totalPage;$i++): ?>
                    <?php if($i == $page): ?>
                    <button class="mdui-btn mdui-color-theme"><?php echo $i; ?></button>
                    <?php else: ?>
                    <a href="?page=<?php echo $i; ?>&sort=<?php echo $sortType; ?>&kw=<?php echo urlencode($keyword); ?>" class="mdui-btn"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                <?php if($page < $totalPage): ?>
                <a href="?page=<?php echo $page+1; ?>&sort=<?php echo $sortType; ?>&kw=<?php echo urlencode($keyword); ?>" class="mdui-btn mdui-btn-icon"><i class="mdui-icon-chevron-right"></i></a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <footer>
        <p><?php echo htmlspecialchars($config['footer_text']); ?></p>
        <?php if(!empty($config['icp'])): ?>
        <p><a href="https://beian.miit.gov.cn/" target="_blank" class="mdui-text-color-grey"><?php echo htmlspecialchars($config['icp']); ?></a></p>
        <?php endif; ?>
    </footer>

    <div class="mdui-dialog" id="infoDialog">
        <div class="mdui-dialog-title">网站详细信息</div>
        <div class="mdui-dialog-content" id="infoContent"></div>
        <div class="mdui-dialog-actions">
            <button class="mdui-btn mdui-ripple" mdui-dialog-close>关闭</button>
            <a href="" class="mdui-btn mdui-color-theme mdui-ripple" id="goUrl">前往网站</a>
        </div>
    </div>

    <script>
    const themeToggle = document.getElementById('themeToggle');
    const html = document.documentElement;
    const savedTheme = localStorage.getItem('theme') || 'light';
    if(savedTheme === 'dark'){
        html.classList.add('dark');
        html.setAttribute('mdui-theme-layout', 'dark');
        themeToggle.innerHTML = '<i class="mdui-icon-light-mode"></i>';
    }
    themeToggle.addEventListener('click', function(){
        if(html.classList.contains('dark')){
            html.classList.remove('dark');
            html.removeAttribute('mdui-theme-layout');
            localStorage.setItem('theme', 'light');
            themeToggle.innerHTML = '<i class="mdui-icon-dark-mode"></i>';
        }else{
            html.classList.add('dark');
            html.setAttribute('mdui-theme-layout', 'dark');
            localStorage.setItem('theme', 'dark');
            themeToggle.innerHTML = '<i class="mdui-icon-light-mode"></i>';
        }
    });

    function showInfo(data){
        let dialog = new mdui.Dialog('#infoDialog');
        let ipArr = data.ip.split('.');
        ipArr[3] = '*';
        let hideIp = ipArr.join('.');
        let intro = data.intro;
        let introHtml = intro;
        if(intro.length > 200){
            introHtml = `
                <div class="intro-content">
                    <div class="intro-collapse" id="introCollapse">${intro}</div>
                    <button class="mdui-btn mdui-btn-text mdui-m-t-1" onclick="toggleIntro()">展开全部</button>
                </div>
            `;
        }
        let html = `
            <div class="mdui-text-center mdui-m-b-3">
                <img src="${data.icon}" style="width:100px;height:100px;border-radius:8px;" onerror="this.style.display='none'">
            </div>
            <p><strong>网站名称：</strong>${data.name} ${data.tag=='recommend'?'<span class="tag tag-recommend">推荐</span>':data.tag=='danger'?'<span class="tag tag-danger">危险</span>':''}</p>
            <p><strong>网站介绍：</strong>${introHtml}</p>
            <p><strong>网站网址：</strong>${data.url}</p>
            <p><strong>上传IP：</strong>${hideIp}</p>
            <p><strong>上传时间：</strong>${data.time}</p>
            <p><strong>访问量：</strong>${data.view}</p>
            ${data.top==1?'<p class="mdui-text-color-red"><strong>状态：已置顶</strong></p>':''}
        `;
        document.getElementById('infoContent').innerHTML = html;
        document.getElementById('goUrl').href = `?viewid=${data.id}&url=${encodeURIComponent(data.url)}`;
        dialog.open();
    }
    function toggleIntro(){
        const collapse = document.getElementById('introCollapse');
        const btn = collapse.nextElementSibling;
        if(collapse.classList.contains('intro-collapse')){
            collapse.classList.remove('intro-collapse');
            btn.textContent = '收起';
        }else{
            collapse.classList.add('intro-collapse');
            btn.textContent = '展开全部';
        }
    }
    </script>
</body>
</html>

<canvas id="sparkCanvas"></canvas>
<link rel="stylesheet" href="./ba-spark/spark.css">
<script src="./ba-spark/spark.js" defer></script>
