<?php
session_start();
$dataFile = 'data.txt';
$now = time();

$lines = file_exists($dataFile) ? file($dataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
$config = [
    'site_name' => '网站收录站',
    'site_desc' => '优质网站收录分享平台',
    'per_page' => 12,
    'footer_text' => '© 2025 网站收录站 版权所有',
    'icp' => '',
    'close_submit' => 0,
    'is_audit' => 0,
    'intro_min' => 10,
    'intro_max' => 500,
    'allow_html_tags' => '<a><img><video><p><br><strong><em>',
    'admin_user' => 'admin',
    'admin_pwd' => 'e10adc3949ba59abbe56e057f20f883e',
    'recycle_days' => 7,
    'dead_link_days' => 30,
    'icon_size' => 128
];

$sites = [];
$logs = [];
$banned_ips = [];

if (!empty($lines)) {
    $cfg = json_decode($lines[0], true);
    if (is_array($cfg)) {
        $config = array_merge($config, $cfg);
        array_shift($lines);
    }
    foreach ($lines as $line) {
        $row = json_decode($line, true);
        if (!$row) continue;
        if (isset($row['action'])) $logs[] = $row;
        elseif (isset($row['ban_time'])) $banned_ips[] = $row;
        elseif (isset($row['id'])) $sites[] = $row;
    }
}

// 自动清理回收站过期
if ($config['recycle_days'] > 0) {
    foreach ($sites as $k => $s) {
        if (!empty($s['deleted_at']) && $s['deleted_at'] + $config['recycle_days'] * 86400 < $now) {
            unset($sites[$k]);
            $logs[] = [
                'time' => date('Y-m-d H:i:s'),
                'ip' => $_SERVER['REMOTE_ADDR'],
                'action' => 'auto_delete',
                'content' => "系统自动删除回收站过期网站：{$s['name']}"
            ];
        }
    }
    $sites = array_values($sites);
}

// 登录处理
if(isset($_POST['login'])){
    if($_POST['user'] == $config['admin_user'] && md5($_POST['pwd']) == $config['admin_pwd']){
        $_SESSION['admin_login'] = true;
        header('Location:admin.php');exit;
    }else{
        $loginErr = '账号或密码错误';
    }
}
if(isset($_GET['logout'])){
    session_destroy();
    header('Location:admin.php');exit;
}
if(empty($_SESSION['admin_login'])){
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mdui@1.0.2/dist/css/mdui.min.css">
<title>管理员登录</title>
</head>
<body class="mdui-theme-primary-indigo" style="padding-top:100px;">
<div class="mdui-container" style="max-width:400px;">
    <div class="mdui-card">
        <div class="mdui-card-header"><div class="mdui-card-header-title">管理员登录</div></div>
        <div class="mdui-card-content">
            <?php if(!empty($loginErr)): ?><div class="mdui-alert mdui-alert-danger"><?php echo $loginErr; ?></div><?php endif; ?>
            <form method="post">
                <div class="mdui-textfield mdui-m-b-3"><label>账号</label><input type="text" name="user" class="mdui-textfield-input" required></div>
                <div class="mdui-textfield mdui-m-b-3"><label>密码</label><input type="password" name="pwd" class="mdui-textfield-input" required></div>
                <button type="submit" name="login" class="mdui-btn mdui-btn-raised mdui-color-theme mdui-float-right">登录</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
<?php
exit;
}

// 保存站点设置
if(isset($_POST['save_config'])){
    $config['site_name']=trim($_POST['site_name']);
    $config['site_desc']=trim($_POST['site_desc']);
    $config['per_page']=(int)$_POST['per_page'];
    $config['footer_text']=trim($_POST['footer_text']);
    $config['icp']=trim($_POST['icp']);
    $config['close_submit']=(int)$_POST['close_submit'];
    $config['is_audit']=(int)$_POST['is_audit'];
    $config['intro_min']=(int)$_POST['intro_min'];
    $config['intro_max']=(int)$_POST['intro_max'];
    $config['allow_html_tags']=trim($_POST['allow_html_tags']);
    $config['recycle_days']=(int)$_POST['recycle_days'];
    $config['dead_link_days']=(int)$_POST['dead_link_days'];
    $config['icon_size']=(int)$_POST['icon_size'];
    if(!empty($_POST['new_user'])) $config['admin_user']=trim($_POST['new_user']);
    if(!empty($_POST['new_pwd'])) $config['admin_pwd']=md5($_POST['new_pwd']);

    $newAll=[json_encode($config,JSON_UNESCAPED_UNICODE)];
    foreach($sites as $s)$newAll[]=json_encode($s,JSON_UNESCAPED_UNICODE);
    foreach($logs as $l)$newAll[]=json_encode($l,JSON_UNESCAPED_UNICODE);
    foreach($banned_ips as $b)$newAll[]=json_encode($b,JSON_UNESCAPED_UNICODE);
    file_put_contents($dataFile,implode(PHP_EOL,$newAll).PHP_EOL);
    header('Location:admin.php?tab=config');exit;
}

// 【修复】置顶/取消置顶 双向切换
if(isset($_GET['top'])){
    $id=(int)$_GET['top'];
    foreach($sites as &$s){
        if((int)$s['id'] === $id){
            $s['top'] = ($s['top'] == 1) ? 0 : 1;
            $logs[]=[
                'time'=>date('Y-m-d H:i:s'),
                'ip'=>$_SERVER['REMOTE_ADDR'],
                'action'=>'top',
                'content'=>($s['top']==1?'置顶成功':'取消置顶成功')."：{$s['name']}"
            ];
            break;
        }
    }
    unset($s);
    $newAll=[json_encode($config,JSON_UNESCAPED_UNICODE)];
    foreach($sites as $x)$newAll[]=json_encode($x,JSON_UNESCAPED_UNICODE);
    foreach($logs as $x)$newAll[]=json_encode($x,JSON_UNESCAPED_UNICODE);
    foreach($banned_ips as $x)$newAll[]=json_encode($x,JSON_UNESCAPED_UNICODE);
    file_put_contents($dataFile,implode(PHP_EOL,$newAll).PHP_EOL);
    header('Location:admin.php?tab=site');exit;
}

// 审核通过
if(isset($_GET['pass'])){
    $id=(int)$_GET['pass'];
    foreach($sites as &$s){
        if((int)$s['id']===$id){
            $s['status']=1;
            $logs[]=['time'=>date('Y-m-d H:i:s'),'ip'=>$_SERVER['REMOTE_ADDR'],'action'=>'audit','content'=>"通过审核：{$s['name']}"];
            break;
        }
    }
    unset($s);
}

// 移入回收站
if(isset($_GET['del'])){
    $id=(int)$_GET['del'];
    foreach($sites as &$s){
        if((int)$s['id']===$id){
            $s['deleted_at']=$now;
            $logs[]=['time'=>date('Y-m-d H:i:s'),'ip'=>$_SERVER['REMOTE_ADDR'],'action'=>'delete','content'=>"移入回收站：{$s['name']}"];
            break;
        }
    }
    unset($s);
}

// 恢复网站
if(isset($_GET['recover'])){
    $id=(int)$_GET['recover'];
    foreach($sites as &$s){
        if((int)$s['id']===$id){
            $s['deleted_at']=null;
            $logs[]=['time'=>date('Y-m-d H:i:s'),'ip'=>$_SERVER['REMOTE_ADDR'],'action'=>'recover','content'=>"恢复网站：{$s['name']}"];
            break;
        }
    }
    unset($s);
}

// 彻底删除
if(isset($_GET['force_del'])){
    $id=(int)$_GET['force_del'];
    foreach($sites as $k=>$s){
        if((int)$s['id']===$id){
            $logs[]=['time'=>date('Y-m-d H:i:s'),'ip'=>$_SERVER['REMOTE_ADDR'],'action'=>'force_delete','content'=>"彻底删除：{$s['name']}"];
            unset($sites[$k]);
            break;
        }
    }
    $sites=array_values($sites);
}

// 设置标签
if(isset($_GET['set_tag'])){
    $id=(int)$_GET['set_tag'];
    $tag=$_GET['tag'];
    foreach($sites as &$s){
        if((int)$s['id']===$id){
            $s['tag']=$tag;
            break;
        }
    }
    unset($s);
}

// 编辑保存
$editId=isset($_GET['edit'])?(int)$_GET['edit']:-1;
if(isset($_POST['edit_save'])){
    $id=(int)$_POST['edit_id'];
    foreach($sites as &$s){
        if((int)$s['id']===$id){
            $s['name']=trim($_POST['name']);
            $s['intro']=strip_tags(trim($_POST['intro']),$config['allow_html_tags']);
            $s['url']=trim($_POST['url']);
            if(!preg_match('/^https?:\/\//i',$s['url']))$s['url']='https://'.$s['url'];
            if(!empty($_FILES['icon']['name'])){
                $ext=strtolower(pathinfo($_FILES['icon']['name'],PATHINFO_EXTENSION));
                $allow=['jpg','png','gif','jpeg','webp'];
                if(in_array($ext,$allow)&&$_FILES['icon']['size']<=512000){
                    if(!is_dir('icon'))mkdir('icon',0777,true);
                    $saveName='icon/'.time().'.'.$ext;
                    move_uploaded_file($_FILES['icon']['tmp_name'],$saveName);
                    $s['icon']=$saveName;
                }
            }
            break;
        }
    }
    unset($s);
    $newAll=[json_encode($config,JSON_UNESCAPED_UNICODE)];
    foreach($sites as $s)$newAll[]=json_encode($s,JSON_UNESCAPED_UNICODE);
    foreach($logs as $l)$newAll[]=json_encode($l,JSON_UNESCAPED_UNICODE);
    foreach($banned_ips as $b)$newAll[]=json_encode($b,JSON_UNESCAPED_UNICODE);
    file_put_contents($dataFile,implode(PHP_EOL,$newAll).PHP_EOL);
    header('Location:admin.php?tab=site');exit;
}

// 批量操作
if(isset($_POST['batch_do'])){
    $ids=$_POST['ids']??[];
    $act=$_POST['batch_act'];
    foreach($ids as $id){
        $id=(int)$id;
        foreach($sites as &$s){
            if((int)$s['id']===$id){
                if($act=='pass')$s['status']=1;
                if($act=='untop')$s['top']=0;
                if($act=='del')$s['deleted_at']=$now;
                if($act=='tag_normal')$s['tag']='normal';
                if($act=='tag_recommend')$s['tag']='recommend';
                if($act=='tag_danger')$s['tag']='danger';
                break;
            }
        }
    }
    unset($s);
    $newAll=[json_encode($config,JSON_UNESCAPED_UNICODE)];
    foreach($sites as $s)$newAll[]=json_encode($s,JSON_UNESCAPED_UNICODE);
    foreach($logs as $l)$newAll[]=json_encode($l,JSON_UNESCAPED_UNICODE);
    foreach($banned_ips as $b)$newAll[]=json_encode($b,JSON_UNESCAPED_UNICODE);
    file_put_contents($dataFile,implode(PHP_EOL,$newAll).PHP_EOL);
    header('Location:admin.php?tab=site');exit;
}

// IP拉黑
if(isset($_POST['add_ban'])){
    $ip=trim($_POST['ban_ip']);
    $days=(int)$_POST['ban_days'];
    $reason=trim($_POST['ban_reason']);
    $expire=$days==0?0:$now+$days*86400;
    $found=false;
    foreach($banned_ips as &$b){
        if($b['ip']==$ip){
            $b['expire']=$expire;
            $b['reason']=$reason;
            $b['ban_time']=date('Y-m-d H:i:s');
            $found=true;
            break;
        }
    }
    unset($b);
    if(!$found)$banned_ips[]=['ip'=>$ip,'ban_time'=>date('Y-m-d H:i:s'),'expire'=>$expire,'reason'=>$reason];
    $newAll=[json_encode($config,JSON_UNESCAPED_UNICODE)];
    foreach($sites as $s)$newAll[]=json_encode($s,JSON_UNESCAPED_UNICODE);
    foreach($logs as $l)$newAll[]=json_encode($l,JSON_UNESCAPED_UNICODE);
    foreach($banned_ips as $b)$newAll[]=json_encode($b,JSON_UNESCAPED_UNICODE);
    file_put_contents($dataFile,implode(PHP_EOL,$newAll).PHP_EOL);
    header('Location:admin.php?tab=ip');exit;
}
if(isset($_GET['unban'])){
    $ip=$_GET['unban'];
    foreach($banned_ips as $k=>$b){
        if($b['ip']==$ip){
            unset($banned_ips[$k]);
            break;
        }
    }
    $banned_ips=array_values($banned_ips);
}

// 统计数据
$wait=0;$total=0;$top=0;
foreach($sites as $s){
    if(empty($s['deleted_at'])){
        $total++;
        if($config['is_audit']&&$s['status']==0)$wait++;
        if(!empty($s['top'])&&$s['top']==1)$top++;
    }
}

$tab=isset($_GET['tab'])?$_GET['tab']:'site';
$sub=isset($_GET['sub'])?$_GET['sub']:'all';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mdui@1.0.2/dist/css/mdui.min.css">
<title>管理后台</title>
</head>
<body class="mdui-theme-primary-indigo" style="padding-top:64px;">
<div class="mdui-appbar mdui-appbar-fixed">
    <div class="mdui-toolbar mdui-color-theme">
        <span class="mdui-typo-headline">管理后台</span>
        <div class="mdui-toolbar-spacer"></div>
        <a href="?logout" class="mdui-btn mdui-text-color-white">退出登录</a>
    </div>
</div>

<div class="mdui-container">
    <div class="mdui-alert mdui-alert-info mdui-m-t-3">
        待审核：<strong><?php echo $wait; ?></strong> &nbsp;
        总收录：<strong><?php echo $total; ?></strong> &nbsp;
        已置顶：<strong><?php echo $top; ?></strong>
    </div>

    <div class="mdui-tab mdui-m-t-3" mdui-tab>
        <a href="?tab=site" class="mdui-tab-item <?php echo $tab=='site'?'mdui-active':''; ?>">网站管理</a>
        <a href="?tab=config" class="mdui-tab-item <?php echo $tab=='config'?'mdui-active':''; ?>">站点设置</a>
        <a href="?tab=ip" class="mdui-tab-item <?php echo $tab=='ip'?'mdui-active':''; ?>">IP管理</a>
        <a href="?tab=log" class="mdui-tab-item <?php echo $tab=='log'?'mdui-active':''; ?>">操作日志</a>
    </div>

    <!-- 网站管理 -->
    <?php if($tab=='site'): ?>
    <div class="mdui-m-t-3">
        <div class="mdui-btn-group mdui-m-b-3">
            <a href="?tab=site&sub=all" class="mdui-btn <?php echo $sub=='all'?'mdui-color-theme':''; ?>">全部</a>
            <a href="?tab=site&sub=wait" class="mdui-btn <?php echo $sub=='wait'?'mdui-color-theme':''; ?>">待审核</a>
            <a href="?tab=site&sub=recycle" class="mdui-btn <?php echo $sub=='recycle'?'mdui-color-theme':''; ?>">回收站</a>
        </div>

        <form method="post" class="mdui-m-b-3">
            <div class="mdui-row">
                <div class="mdui-col-xs-12 mdui-col-sm-3">
                    <select name="batch_act" class="mdui-select" required>
                        <option value="">批量操作</option>
                        <option value="pass">批量通过</option>
                        <option value="untop">批量取消置顶</option>
                        <option value="del">批量删除</option>
                        <option value="tag_normal">标记普通</option>
                        <option value="tag_recommend">标记推荐</option>
                        <option value="tag_danger">标记危险</option>
                    </select>
                </div>
                <div class="mdui-col-xs-12 mdui-col-sm-3">
                    <button type="submit" name="batch_do" class="mdui-btn mdui-color-theme">执行</button>
                </div>
            </div>
        </form>

        <div class="mdui-table-fluid">
            <table class="mdui-table mdui-table-hover">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="checkAll"></th>
                        <th>图标</th>
                        <th>名称</th>
                        <th>访问量</th>
                        <th>状态</th>
                        <th>标签</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $list=[];
                foreach($sites as $s){
                    if($sub=='all'&&empty($s['deleted_at']))$list[]=$s;
                    if($sub=='wait'&&empty($s['deleted_at'])&&$config['is_audit']&&$s['status']==0)$list[]=$s;
                    if($sub=='recycle'&&!empty($s['deleted_at']))$list[]=$s;
                }
                foreach($list as $s):
                ?>
                    <tr>
                        <td><input type="checkbox" name="ids[]" value="<?php echo $s['id']; ?>" class="checkItem"></td>
                        <td><img src="<?php echo htmlspecialchars($s['icon']); ?>" style="width:40px;height:40px;border-radius:4px;"></td>
                        <td><?php echo htmlspecialchars($s['name']); ?></td>
                        <td><?php echo $s['view']; ?></td>
                        <td>
                            <?php if(!empty($s['deleted_at'])): ?>
                                <span class="mdui-text-color-red">回收站</span>
                            <?php elseif($config['is_audit']&&$s['status']==0): ?>
                                <span class="mdui-text-color-orange">待审核</span>
                            <?php else: ?>
                                <span class="mdui-text-color-green">正常</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($s['tag']=='recommend'): ?><span class="mdui-text-color-green">推荐</span>
                            <?php elseif($s['tag']=='danger'): ?><span class="mdui-text-color-red">危险</span>
                            <?php else: ?>普通<?php endif; ?>
                        </td>
                        <td>
                            <?php if(empty($s['deleted_at'])): ?>
                                <?php if($config['is_audit']&&$s['status']==0): ?>
                                    <a href="?tab=site&sub=wait&pass=<?php echo $s['id']; ?>" class="mdui-btn mdui-btn-sm mdui-color-green">通过</a>
                                <?php endif; ?>
                                <a href="?tab=site&top=<?php echo $s['id']; ?>" class="mdui-btn mdui-btn-sm <?php echo $s['top']==1?'mdui-color-red':'mdui-color-grey'; ?>">
                                    <?php echo $s['top']==1?'取消置顶':'置顶'; ?>
                                </a>
                                <a href="?tab=site&edit=<?php echo $s['id']; ?>" class="mdui-btn mdui-btn-sm mdui-color-blue">编辑</a>
                                <a href="?tab=site&del=<?php echo $s['id']; ?>" class="mdui-btn mdui-btn-sm mdui-color-red">删除</a>
                                <div class="mdui-dropdown" style="display:inline;">
                                  <button class="mdui-btn mdui-btn-sm">标记▼</button>
                                  <div class="mdui-dropdown-menu">
                                    <a href="?tab=site&set_tag=<?php echo $s['id']; ?>&tag=normal" class="mdui-dropdown-item">普通</a>
                                    <a href="?tab=site&set_tag=<?php echo $s['id']; ?>&tag=recommend" class="mdui-dropdown-item">推荐</a>
                                    <a href="?tab=site&set_tag=<?php echo $s['id']; ?>&tag=danger" class="mdui-dropdown-item">危险</a>
                                  </div>
                                </div>
                            <?php else: ?>
                                <a href="?tab=site&sub=recycle&recover=<?php echo $s['id']; ?>" class="mdui-btn mdui-btn-sm mdui-color-green">恢复</a>
                                <a href="?tab=site&sub=recycle&force_del=<?php echo $s['id']; ?>" class="mdui-btn mdui-btn-sm mdui-color-red">彻底删除</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if($editId>0):
        $editSite=null;foreach($sites as $s){if((int)$s['id']==$editId){$editSite=$s;break;}}
        if($editSite):
        ?>
        <div class="mdui-card mdui-m-t-3">
            <div class="mdui-card-header"><div class="mdui-card-header-title">编辑网站</div></div>
            <div class="mdui-card-content">
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="edit_id" value="<?php echo $editSite['id']; ?>">
                    <div class="mdui-textfield mdui-m-b-3"><label>网站名称</label><input type="text" name="name" class="mdui-textfield-input" value="<?php echo htmlspecialchars($editSite['name']); ?>" required></div>
                    <div class="mdui-textfield mdui-m-b-3"><label>网站网址</label><input type="text" name="url" class="mdui-textfield-input" value="<?php echo htmlspecialchars($editSite['url']); ?>" required></div>
                    <div class="mdui-textfield mdui-m-b-3"><label>网站介绍</label><textarea name="intro" class="mdui-textfield-input" rows="4" required><?php echo htmlspecialchars($editSite['intro']); ?></textarea></div>
                    <div class="mdui-m-b-3">
                        <label>更换图标（选填）</label>
                        <input type="file" name="icon" accept="image/*">
                        <div class="mdui-m-t-2"><img src="<?php echo htmlspecialchars($editSite['icon']); ?>" style="width:60px;height:60px;border-radius:4px;"></div>
                    </div>
                    <button type="submit" name="edit_save" class="mdui-btn mdui-color-theme">保存修改</button>
                    <a href="admin.php?tab=site" class="mdui-btn">取消</a>
                </form>
            </div>
        </div>
        <?php endif;endif; ?>
    </div>
    <?php endif; ?>

    <!-- 站点设置 -->
    <?php if($tab=='config'): ?>
    <div class="mdui-card mdui-m-t-3">
        <div class="mdui-card-header"><div class="mdui-card-header-title">站点基础设置</div></div>
        <div class="mdui-card-content">
            <form method="post">
                <div class="mdui-textfield mdui-m-b-3"><label>网站名称</label><input type="text" name="site_name" class="mdui-textfield-input" value="<?php echo htmlspecialchars($config['site_name']); ?>" required></div>
                <div class="mdui-textfield mdui-m-b-3"><label>网站描述</label><input type="text" name="site_desc" class="mdui-textfield-input" value="<?php echo htmlspecialchars($config['site_desc']); ?>" required></div>
                <div class="mdui-textfield mdui-m-b-3"><label>每页显示数量</label><input type="number" name="per_page" class="mdui-textfield-input" value="<?php echo $config['per_page']; ?>" required></div>
                <div class="mdui-textfield mdui-m-b-3"><label>底部版权文字</label><input type="text" name="footer_text" class="mdui-textfield-input" value="<?php echo htmlspecialchars($config['footer_text']); ?>" required></div>
                <div class="mdui-textfield mdui-m-b-3"><label>备案号</label><input type="text" name="icp" class="mdui-textfield-input" value="<?php echo htmlspecialchars($config['icp']); ?>"></div>

                <div class="mdui-row mdui-m-b-3">
                    <div class="mdui-col-xs-6">
                        <label class="mdui-checkbox"><input type="checkbox" name="close_submit" value="1" <?php if($config['close_submit'])echo 'checked';?>><i class="mdui-checkbox-icon"></i>关闭前台提交</label>
                    </div>
                    <div class="mdui-col-xs-6">
                        <label class="mdui-checkbox"><input type="checkbox" name="is_audit" value="1" <?php if($config['is_audit'])echo 'checked';?>><i class="mdui-checkbox-icon"></i>开启审核</label>
                    </div>
                </div>

                <div class="mdui-textfield mdui-m-b-3"><label>简介最少字数</label><input type="number" name="intro_min" class="mdui-textfield-input" value="<?php echo $config['intro_min']; ?>" required></div>
                <div class="mdui-textfield mdui-m-b-3"><label>简介最多字数</label><input type="number" name="intro_max" class="mdui-textfield-input" value="<?php echo $config['intro_max']; ?>" required></div>
                <div class="mdui-textfield mdui-m-b-3"><label>允许HTML标签</label><input type="text" name="allow_html_tags" class="mdui-textfield-input" value="<?php echo htmlspecialchars($config['allow_html_tags']); ?>" required></div>

                <div class="mdui-textfield mdui-m-b-3"><label>回收站保留天数</label><input type="number" name="recycle_days" class="mdui-textfield-input" value="<?php echo $config['recycle_days']; ?>" required></div>
                <div class="mdui-textfield mdui-m-b-3"><label>图标尺寸(px)</label><input type="number" name="icon_size" class="mdui-textfield-input" value="<?php echo $config['icon_size']; ?>" required></div>

                <div class="mdui-textfield mdui-m-b-3"><label>新管理员账号</label><input type="text" name="new_user" class="mdui-textfield-input" placeholder="留空则不变"></div>
                <div class="mdui-textfield mdui-m-b-3"><label>新管理员密码</label><input type="password" name="new_pwd" class="mdui-textfield-input" placeholder="留空则不变"></div>

                <button type="submit" name="save_config" class="mdui-btn mdui-color-theme">保存所有设置</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- IP管理 -->
    <?php if($tab=='ip'): ?>
    <div class="mdui-card mdui-m-t-3">
        <div class="mdui-card-header"><div class="mdui-card-header-title">IP拉黑管理</div></div>
        <div class="mdui-card-content">
            <form method="post" class="mdui-m-b-3">
                <div class="mdui-row mdui-valign">
                    <div class="mdui-col-xs-3">
                        <input type="text" name="ban_ip" class="mdui-textfield-input" placeholder="IP地址" required>
                    </div>
                    <div class="mdui-col-xs-2">
                        <input type="number" name="ban_days" class="mdui-textfield-input" placeholder="天数" required>
                    </div>
                    <div class="mdui-col-xs-4">
                        <input type="text" name="ban_reason" class="mdui-textfield-input" placeholder="拉黑原因">
                    </div>
                    <div class="mdui-col-xs-3">
                        <button type="submit" name="add_ban" class="mdui-btn mdui-color-theme">添加/更新拉黑</button>
                    </div>
                </div>
            </form>

            <div class="mdui-table-fluid">
                <table class="mdui-table mdui-table-hover">
                    <thead>
                        <tr>
                            <th>IP地址</th>
                            <th>拉黑时间</th>
                            <th>到期时间</th>
                            <th>原因</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($banned_ips as $b): ?>
                    <tr>
                        <td><?php echo $b['ip']; ?></td>
                        <td><?php echo $b['ban_time']; ?></td>
                        <td>
                            <?php if($b['expire']==0): ?>
                                <span class="mdui-text-color-red">永久拉黑</span>
                            <?php else: ?>
                                <?php echo date('Y-m-d H:i:s',$b['expire']); ?>
                                <?php if($b['expire']<$now): ?><span class="mdui-text-color-grey">(已过期)</span><?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($b['reason']); ?></td>
                        <td>
                            <a href="?tab=ip&unban=<?php echo $b['ip']; ?>" class="mdui-btn mdui-btn-sm mdui-color-green">解封</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- 操作日志 -->
    <?php if($tab=='log'): ?>
    <div class="mdui-card mdui-m-t-3">
        <div class="mdui-card-header"><div class="mdui-card-header-title">操作日志</div></div>
        <div class="mdui-card-content">
            <div class="mdui-table-fluid">
                <table class="mdui-table mdui-table-hover">
                    <thead>
                        <tr>
                            <th>时间</th>
                            <th>IP</th>
                            <th>操作类型</th>
                            <th>详情</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $revLogs = array_reverse($logs);
                    foreach(array_slice($revLogs,0,50) as $l): 
                    ?>
                    <tr>
                        <td><?php echo $l['time']; ?></td>
                        <td><?php echo $l['ip']; ?></td>
                        <td><?php echo $l['action']; ?></td>
                        <td><?php echo htmlspecialchars($l['content']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
// 全选
document.getElementById('checkAll').addEventListener('change',function(){
    let items = document.querySelectorAll('.checkItem');
    items.forEach(i=>i.checked = this.checked);
});
</script>
</body>
</html>


<canvas id="sparkCanvas"></canvas>
<link rel="stylesheet" href="./ba-spark/spark.css">
<script src="./ba-spark/spark.js" defer></script>
