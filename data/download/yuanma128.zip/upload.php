<?php
session_start();
$dataFile = 'data.txt';
$msg = '';
$ip = $_SERVER['REMOTE_ADDR'];
$today = date('Y-m-d');
$now = time();

$lines = file_exists($dataFile) ? file($dataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
$config = [
    'is_audit' => 0,
    'ip_day_limit' => 3,
    'site_name' => '网站收录站',
    'allow_html_tags' => '<a><img><video><p><br><strong><em>',
    'intro_min' => 10,
    'intro_max' => 500,
    'close_submit' => 0,
    'icon_size' => 128
];
$sites = [];
$logs = [];
$banned_ips = [];

if (!empty($lines)) {
    $cfg = json_decode($lines[0], true);
    if (isset($cfg['is_audit'])) {
        $config = array_merge($config, $cfg);
        array_shift($lines);
    }
    foreach ($lines as $line) {
        $row = json_decode($line, true);
        if (!$row) continue;
        if (isset($row['action'])) $logs[] = $row;
        elseif (isset($row['ban_time'])) $banned_ips[] = $row;
        elseif (isset($row['id'])) $sites[] = $row;
    }
}

// IP拉黑检测
foreach ($banned_ips as $b) {
    if ($b['ip'] == $ip && ($b['expire'] == 0 || $b['expire'] > $now)) {
        $msg = '您的IP已被禁止提交网站，请联系管理员！';
        break;
    }
}
if ($config['close_submit']) $msg = '网站已关闭用户提交功能！';

// 每日提交次数限制
$count = 0;
foreach ($sites as $s) {
    $sDate = date('Y-m-d', strtotime($s['time']));
    if ($s['ip'] == $ip && $sDate == $today) $count++;
}
if ($count >= $config['ip_day_limit'] && empty($msg)) {
    $msg = "今日提交已达上限（{$config['ip_day_limit']}个）！";
}

// 提交处理
if($_POST && empty($msg)){
    $lastSubmit = $_SESSION['last_submit'] ?? 0;
    if($now - $lastSubmit < 60){
        $msg = '提交过于频繁，请60秒后再试！';
        goto endPost;
    }

    $name = trim($_POST['name']);
    $intro = trim($_POST['intro']);
    $url = trim($_POST['url']);
    $autoIcon = isset($_POST['auto_icon']);
    $time = date('Y-m-d H:i:s');
    $icon = '';

    // 自动补全http/https
    if(!preg_match('/^https?:\/\//i', $url)) $url = 'https://' . $url;

    // 检测重复收录
    foreach($sites as $s){
        if(strtolower($s['url']) == strtolower($url) && empty($s['deleted_at'])){
            $msg = '该网址已收录，请勿重复提交！';
            break;
        }
    }
    if(!empty($msg)) goto endPost;

    // 简介字数校验
    $introLen = mb_strlen($intro);
    if($introLen < $config['intro_min'] || $introLen > $config['intro_max']){
        $msg = "简介字数需在 {$config['intro_min']}-{$config['intro_max']} 字之间！";
        goto endPost;
    }

    if(empty($name)||empty($intro)||empty($url)){
        $msg = '请填写完整网站名称、介绍和网址！';
        goto endPost;
    }

    // 过滤多余HTML标签
    $intro = strip_tags($intro, $config['allow_html_tags']);

    // 图标处理
    if($autoIcon){
        $icon = 'https://www.google.com/s2/favicons?domain='.$url.'&sz='.$config['icon_size'];
    }else{
        if(!empty($_FILES['icon']['name'])){
            $allow = ['jpg','png','gif','jpeg','webp'];
            $ext = strtolower(pathinfo($_FILES['icon']['name'],PATHINFO_EXTENSION));
            if(!in_array($ext,$allow)){
                $msg = '图标仅支持 jpg/png/gif/jpeg/webp 格式';
            }elseif($_FILES['icon']['size'] > 512000){
                $msg = '图标文件不能大于500KB';
            }else{
                if(!is_dir('icon')) mkdir('icon',0777,true);
                $saveName = 'icon/'.time().'.'.$ext;
                move_uploaded_file($_FILES['icon']['tmp_name'],$saveName);
                $icon = $saveName;
            }
        }else{
            $msg = '请上传图标 或 勾选自动获取网站图标！';
        }
    }

endPost:
    // 保存数据
    if(empty($msg)){
        $status = $config['is_audit'] ? 0 : 1;
        $data = [
            'id' => time() + rand(1000,9999),
            'name'=>$name,
            'intro'=>$intro,
            'url'=>$url,
            'icon'=>$icon,
            'ip'=>$ip,
            'time'=>$time,
            'status'=>$status,
            'top'=>0,
            'view'=>0,
            'last_view'=>$now,
            'tag'=>'normal',
            'deleted_at'=>null
        ];
        $logs[] = [
            'time'=>$time,
            'ip'=>$ip,
            'action'=>'submit',
            'content'=>"用户提交网站：{$name}"
        ];
        $newAll = [json_encode($config,JSON_UNESCAPED_UNICODE)];
        foreach($sites as $s) $newAll[] = json_encode($s,JSON_UNESCAPED_UNICODE);
        $newAll[] = json_encode($data,JSON_UNESCAPED_UNICODE);
        foreach($logs as $l) $newAll[] = json_encode($l,JSON_UNESCAPED_UNICODE);
        foreach($banned_ips as $b) $newAll[] = json_encode($b,JSON_UNESCAPED_UNICODE);
        file_put_contents($dataFile,implode(PHP_EOL,$newAll).PHP_EOL);
        $_SESSION['last_submit'] = $now;
        $msg = $config['is_audit'] ? '提交成功，等待管理员审核！' : '提交成功，已自动收录！';
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>提交网站 - <?php echo htmlspecialchars($config['site_name']); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mdui@1.0.2/dist/css/mdui.min.css">
</head>
<body class="mdui-theme-primary-indigo" style="padding-top:64px;">
    <header class="mdui-appbar mdui-appbar-fixed">
        <div class="mdui-toolbar mdui-color-theme">
            <a href="index.php" class="mdui-typo-headline">返回首页</a>
            <div class="mdui-toolbar-spacer"></div>
            <a href="admin.php" class="mdui-btn mdui-text-color-white">管理后台</a>
        </div>
    </header>

    <div class="mdui-container" style="max-width:600px;margin-top:80px;">
        <div class="mdui-card">
            <div class="mdui-card-header">
                <div class="mdui-card-header-title">提交网站收录</div>
            </div>
            <div class="mdui-card-content">
                <?php if(!empty($msg)): ?>
                    <div class="mdui-alert <?php echo isset($success)?'mdui-alert-success':'mdui-alert-warning'; ?>">
                        <?php echo $msg; ?>
                    </div>
                    <?php if(isset($success)): ?>
                    <script>setTimeout(()=>location.href='index.php',2000);</script>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(empty($msg) || !isset($success)): ?>
                <div class="mdui-alert mdui-alert-info mdui-m-b-4">
                    <strong>提交须知</strong>
                    <ul class="mdui-m-0 mdui-p-l-20">
                        <li>网站内容合法、可正常访问</li>
                        <li>简介限制 <?php echo $config['intro_min']; ?>-<?php echo $config['intro_max']; ?> 字</li>
                        <li>同一IP每日最多提交 <?php echo $config['ip_day_limit']; ?> 个网站</li>
                    </ul>
                </div>

                <form method="post" enctype="multipart/form-data" id="submitForm">
                    <div class="mdui-textfield mdui-m-b-3">
                        <label>网站名称</label>
                        <input type="text" name="name" class="mdui-textfield-input" required>
                    </div>
                    <div class="mdui-textfield mdui-m-b-3">
                        <label>网站介绍</label>
                        <textarea name="intro" class="mdui-textfield-input" rows="3" required id="introInput"></textarea>
                        <div class="mdui-textfield-helper">已输入：<span id="introCount">0</span> / <?php echo $config['intro_max']; ?></div>
                    </div>
                    <div class="mdui-textfield mdui-m-b-3">
                        <label>网站网址</label>
                        <input type="text" name="url" class="mdui-textfield-input" placeholder="无需加http://" required>
                    </div>

                    <label class="mdui-checkbox mdui-m-b-3">
                        <input type="checkbox" name="auto_icon" id="autoIcon" checked>
                        <i class="mdui-checkbox-icon"></i>自动抓取网站官方图标
                    </label>

                    <div class="mdui-m-b-3" id="uploadIconBox" style="display:none;">
                        <label>手动上传图标（格式jpg/png/gif，最大500KB）</label>
                        <input type="file" name="icon" accept="image/*" class="mdui-m-t-2">
                    </div>

                    <button type="submit" class="mdui-btn mdui-color-theme mdui-float-right">立即提交收录</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    // 简介字数统计
    document.getElementById('introInput').addEventListener('input',function(){
        document.getElementById('introCount').innerText = this.value.length;
    });
    // 自动图标勾选切换上传框
    document.getElementById('autoIcon').addEventListener('change',function(){
        document.getElementById('uploadIconBox').style.display = this.checked ? 'none' : 'block';
    });
    </script>
</body>
</html>


<canvas id="sparkCanvas"></canvas>
<link rel="stylesheet" href="./ba-spark/spark.css">
<script src="./ba-spark/spark.js" defer></script>
